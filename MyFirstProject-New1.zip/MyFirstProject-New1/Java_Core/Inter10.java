public interface Inter10
{
    int d=10;
    int f=9;
    public void printd(Call6 obj);
    public void printf(Call6 obj);
}