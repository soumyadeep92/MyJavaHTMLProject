import java.io.*;
public class Access1_sub extends Access1
{
    public static void main(String[]args)throws IOException
    {
        Access1_sub obj=new Access1_sub();
        obj.input();
        obj.print();
        obj.main(args);
    }
}