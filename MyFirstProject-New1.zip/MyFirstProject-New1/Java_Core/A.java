import java.io.*;
public class A
{
    int n;
    public void printHello()
    {
        n=1;
        System.out.println(n);
        System.out.println("HELLO");
    }
    public void printLove()
    {
        n=2;
        System.out.println(n);
        System.out.println("LOVE");
    }
    public void printHi()
    {
        n=3;
        System.out.println(n);
        System.out.println("Hi Everyone!");
    }
}