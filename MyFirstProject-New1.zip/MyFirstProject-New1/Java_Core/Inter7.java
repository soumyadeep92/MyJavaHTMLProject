public interface Inter7
{
    void difference(int a, int b);
}