public interface Inter11
{
    private void print(){}
}