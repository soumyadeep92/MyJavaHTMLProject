public class Loop1
{
    public void print()
    {
        for(int i=0;i<10;i++)
        {
            System.out.println("Bright IT Career");
        }
    }
    public static void main(String []args)
    {
        Loop1 obj=new Loop1();
        obj.print();
    }
}