public class Main
{
    public static void main(String []args)
    {
        Sub_Construct2 obj=new Sub_Construct2();
    }
}