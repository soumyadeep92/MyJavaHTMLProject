public class C extends B
{
    int n;
    public void Hello()
    {
        n=21;
        System.out.println(n);
        System.out.println("Hello World..");
    }
    public void Love()
    {
        n=22;
        System.out.println(n);
        System.out.println("God's love is wonderful...");
    }
    public void printHi()
    {
        n=23;
        System.out.println(n);
        System.out.println("Hi this is Java..");
    }
}