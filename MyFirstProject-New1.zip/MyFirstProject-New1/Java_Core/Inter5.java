public interface Inter5
{
    public void printSame();
}