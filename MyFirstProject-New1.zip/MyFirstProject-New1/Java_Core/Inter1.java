public interface Inter1
{
    public int find(int n,int x);
}