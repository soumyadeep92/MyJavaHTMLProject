public interface Inter6
{
    public void printSame();
}