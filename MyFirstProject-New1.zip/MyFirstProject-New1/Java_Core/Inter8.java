public interface Inter8
{
    public void Enable();
}