public interface Inter12
{
    static final int j=3;
}