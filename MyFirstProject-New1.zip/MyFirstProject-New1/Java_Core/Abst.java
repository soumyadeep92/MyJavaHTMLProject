public abstract class Abst
{
    public abstract void temp();
    public void test()
    {
        System.out.println("This function is non-abstract function 1");
    }
    public void assume()
    {
        System.out.println("This method is non-abstract method 2");
    }
}