public interface Inter3
{
    public int real(int n);
}