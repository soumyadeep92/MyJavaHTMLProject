public class B extends A
{
    int n;
    public void sayHello()
    {
        n=11;
        System.out.println(n);        
        System.out.println("Hello Everyone!!");
    }
    public void sayLove()
    {
        n=12;
        System.out.println(n);
        System.out.println("Love is universal.");
    }
    public void printHi()
    {
        n=13;
        System.out.println(n);
        System.out.println("Hi!!");
    }
}