public class Other1_sub extends Other1
{
    public Other1_sub()
    {
        super();
        System.out.println("Using super in subclass: ");
    }
    public void sub()
    {
        super.use();
    }
}