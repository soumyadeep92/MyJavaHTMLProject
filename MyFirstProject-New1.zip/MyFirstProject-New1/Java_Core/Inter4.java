public interface Inter4
{
    public void printReal();
}