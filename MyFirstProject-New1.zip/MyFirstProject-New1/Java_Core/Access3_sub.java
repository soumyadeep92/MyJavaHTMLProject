import java.io.*;
public class Access3_sub extends Access3
{
    public static void main(String[]args)throws IOException
    {
        Access3_sub obj=new Access3_sub();
        obj.input();
        obj.print();
    }
}