public class Call7 implements Inter11
{
    private void print()
    {
        System.out.println("The interface is private...");
    }
    public static void main(String []args)
    {
        Call7 obj=new Call7();
        obj.print();
    }
} 