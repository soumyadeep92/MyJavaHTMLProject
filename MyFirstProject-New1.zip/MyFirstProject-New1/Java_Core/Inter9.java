public interface Inter9 extends Inter8
{
    public void Disable();
}