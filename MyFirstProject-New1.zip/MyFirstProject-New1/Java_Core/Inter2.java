public interface Inter2
{
    public void printName();
    public void printNum();
}