public class Construct2
{
    Construct2()
    {
        System.out.println("Superclass");
    }
}
